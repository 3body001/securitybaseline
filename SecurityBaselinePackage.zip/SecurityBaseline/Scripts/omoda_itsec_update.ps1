# omoda_itsec_update.ps1
# This script downloads and updates the omoda_itsec.ps1 script

$downloadUrl = "https://raw.githubusercontent.com/3body001/securitybaseline/main/omoda_itsec.ps1"
$destinationPath = "C:\Omoda\SecurityBaseline\Scripts\omoda_itsec.ps1"

function Download-File {
    param (
        [string]$url,
        [string]$output
    )
    try {
        Invoke-WebRequest -Uri $url -OutFile $output
        Write-Host "Downloaded file to $output"
    } catch {
        Write-Error "Failed to download file from $url. $_"
        exit 1
    }
}

# Ensure the destination directory exists
$destinationDir = Split-Path -Path $destinationPath -Parent
if (-Not (Test-Path $destinationDir)) {
    New-Item -Path $destinationDir -ItemType Directory
}

# Download and update the omoda_itsec.ps1 script
Download-File -url $downloadUrl -output $destinationPath
